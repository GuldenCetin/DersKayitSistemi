# Docs
* [Home](../ReadMe.md)

## Table of contents
* [Compling tesseract and leptonica.md](./Compling_tesseract_and_leptonica.md)
* [Examples](./examples.md)

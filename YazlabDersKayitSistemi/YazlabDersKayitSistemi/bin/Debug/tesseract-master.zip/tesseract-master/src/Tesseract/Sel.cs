﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tesseract
{
    public enum SelType : int
    {
        SEL_DONT_CARE = 0,
        SEL_HIT = 1,
        SEL_MISS = 2
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tesseract
{
    public enum AddNewColorStatus
    {
        Ok = 0,
        Error = 1,
        NotEnoughSpace = 2
    }
}
